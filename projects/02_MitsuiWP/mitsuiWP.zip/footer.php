<footer class="page-footer footer pb-4 bg-dark">
					<div class="footer-top border-md-bottom">
						<div class="container">
							<div class="row m-0">
								<div class="list-inline-item border-bottom border-secondary col-12 col-md-auto py-2 mr-0 md-res">
								<a href="http://simasaki.xsrv.jp" class="text-light">Home</a>
							</div>
							<div class="list-inline-item border-bottom border-secondary col-12 col-md-auto py-2 mr-0 md-res">
								<a href="http://simasaki.xsrv.jp/aboutus.html" class="text-light">About</a>
							</div>
							<div class="list-inline-item border-bottom border-secondary col-12 col-md-auto py-2 mr-0 md-res">
								<a href="http://simasaki.xsrv.jp/service.html" class="text-light">Servis</a>
							</div>
							<div class="list-inline-item border-bottom border-secondary col-12 col-md-auto py-2 mr-0 md-res">
								<a href="http://simasaki.xsrv.jp/access.html" class="text-light">Access</a>
							</div>
							<div class="list-inline-item border-bottom border-secondary col-12 col-md-auto py-2 mr-0 md-res">
								<a href="http://simasaki.xsrv.jp/blog.html" class="text-light">blog</a>
							</div>
							<div class="list-inline-item border-bottom border-secondary col-12 col-md-auto py-2 mr-0 md-res">
								<a href="https://www.facebook.com/mitsuijidousha/" class="text-light">facebook</a>
							</div>
							<div class="list-inline-item border-bottom border-secondary col-12 col-md-auto py-2 mr-0 md-res border-md-right">
								<a href="http://simasaki.xsrv.jp/form.html" class="text-light">お問い合わせ</a>
							</div>
						</div>
					</div>
				</div>

				<div class="text-center mt-5 mx-5 text-secondary">
					<p class="copyright">Copyright © Mitui All Rights Reserved.<br>Powered by WordPress with Lightning Theme & VK All in One Expansion Unit by Vektor,Inc. technology.</p>
				</div>

		</footer>


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
    <script>
      $(function(){
        'use strict';
        $('[data-toggle="tooltip"]').tooltip();        $
      });
    </script>
		<?php wp_footer(); ?>  
  </body>
</html>